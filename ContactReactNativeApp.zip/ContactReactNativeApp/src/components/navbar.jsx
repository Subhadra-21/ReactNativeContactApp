import React, {Component} from 'react';

import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';

export default class NavBar extends Component{
    render(){
        const navList = [{title: "home", id:"home"}, {title: "TicTacToe", id:"ticTacToe"},{title: "Audio", id:"audio"}, {title: "LuckyDraw", id:"luckyDraw"},];
        return (
            <View
                style={{
                flex: 1,
                backgroundColor: "white",
                justifyContent: "center",
                }}
            >
                <View>
                 {
                     navList.map((nav)=>{
                         return <TouchableOpacity key={nav.id} style={styles.listItem}><Text style={styles.listText} onPress={()=>this.props.handleClick(nav.id)}>{nav.title}</Text></TouchableOpacity>
                     })
                 }
                </View>
            </View>
        
        );
    }
}

const styles = StyleSheet.create({
    listItem: {
        justifyContent: "center",
        alignItems: "center",
        borderTopWidth: 2,
        borderTopColor: "green",
        borderBottomWidth: 2,
        borderBottomColor: "green",
        padding:5,
        marginBottom: 2
    },
    listText: {
        color: "red"
    }
});