
import React, {Component} from 'react';

import {View, Text, TouchableOpacity, Image, StyleSheet, Button} from 'react-native';

import {Audio} from 'expo-av';

var gridData = [{label:1},{label:2},{label:3},{label:4},{label:5},{label:6},{label:7},{label:8},{label:9},{label:10}];
var soundMap = {
    1: require('../../assets/spanish/assets/one.wav'),
    2: require('../../assets/spanish/assets/two.wav'),
    3: require('../../assets/spanish/assets/three.wav'),
    4: require('../../assets/spanish/assets/four.wav'),
    5: require('../../assets/spanish/assets/five.wav'),
    6: require('../../assets/spanish/assets/six.wav'),
    7: require('../../assets/spanish/assets/seven.wav'),
    8: require('../../assets/spanish/assets/eight.wav'),
    9: require('../../assets/spanish/assets/nine.wav'),
    10: require('../../assets/spanish/assets/ten.wav'),
}
export default class AudioPlay extends Component{
    async playSound(num){
        const soundObj = new Audio.Sound();
        try{
            let path = soundMap[num];
            await soundObj.loadAsync(path);
            await soundObj.playAsync()
            .then(async playbackstatus=>{
                setTimeout(()=>{
                    soundObj.unloadAsync()
                },playbackstatus.playableDurationMillis);
            }).catch(err=>{
                console.log(err)
            })
           //  await soundObj.unloadAsync();
        }catch(err){
            console.log(err);
        }
    }
    render(){
        return (
            <View style={styles.container}>
                <Text style={styles.heading}>Play Audio</Text>
                <View style={styles.tttcontainer}>
                    {
                        gridData.map((grid, i) => {
                            return (
                            <TouchableOpacity key={i} onPress={()=>{this.playSound(grid.label)}} style={[styles.cellcontainer]}>
                                <View>
                                    <Text>{grid.label}</Text>
                                </View>
                            </TouchableOpacity>
                            )
                        })
                    }
                </View>
            </View>
        );
    }
}

/*
export default class AudioPlay extends Component{
    async playSound(num){
        const soundObj = new Audio.Sound();
        try{
            let path = soundMap[num];
            await soundObj.loadAsync(path);
            await soundObj
            .playAsync()
            .then(async playbackstatus=>{
                setTimeout(()=>{
                    soundObj.unloadAsync()
                },playbackstatus.playableDurationMillis);
            }).catch(err=>{
                console.log(err)
            })
        }catch(err){
            console.log(err);
        }
    }
    render(){
        return (
            <View style={styles.container}>
                <Text style={styles.heading}>Play Audio</Text>
                <View style={styles.tttcontainer}>
                    {
                        gridData.map((grid, i) => {
                            return (
                            <TouchableOpacity key={i} onPress={()=>{this.playSound(grid.label)}} style={[styles.cellcontainer]}>
                                <View>
                                    <Text>{grid.label}</Text>
                                </View>
                            </TouchableOpacity>
                            )
                        })
                    }
                </View>
            </View>
        );
    }
}
*/

const styles = StyleSheet.create({
    container: {
       width: "100%",
       justifyContent: "center",
       alignItems: "center",
       paddingTop: 20,
       height: "100%",
       backgroundColor: "#31c2fe"
    },
    heading:{
        color: "red",
        fontWeight: "bold",
        fontSize: 22,
        width: "80%",
        paddingBottom: 20
    },
    tttcontainer: {
        backgroundColor: "#ffc931",
        height: 250,
        flexWrap: "wrap",
        width: "90%"
    },
    cellcontainer: {
        width: "50%",
        height: 50,
        borderWidth:1,
        borderColor: "black",
        justifyContent: "center",
        alignItems: "center"
    }
});