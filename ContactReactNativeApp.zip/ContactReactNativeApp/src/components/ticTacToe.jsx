
import React, {Component} from 'react';

import {View, Text, TouchableOpacity, Image, StyleSheet, Button} from 'react-native';

var gridData = new Array(9);
gridData.fill('def');
var winIdx = [];
export default class TicTacToe extends Component{
    constructor(props){
        super(props);
        this.state = {
            isCross : true,
            winType: ""
        };
        this.setItem = this.setItem.bind(this);
        this.resetGame = this.resetGame.bind(this);
    }

    setItem(index){
        if(gridData[index] !== "def") return;
        if( this.state.winType) return;
        gridData[index] = this.state.isCross ? 'cross' : 'circle';
        this.setState({isCross : !this.state.isCross }, ()=>{
            this.checkWinGame();
        });
    }

    choseItemIcon(type){
        switch(type){
            case "cross" : 
                return <Image source={require('../../assets/images/ttt_x.png')} style={styles.icon}/>;
            case 'circle': 
                return <Image source={require('../../assets/images/ttt_o.png')} style={styles.icon}/>
            default: return null; 
        }
    }

    resetGame(){
        gridData = new Array(9);
        gridData.fill('def');
        winIdx = [];
        this.setState({isCross : true, winType: ""});
    }

    checkWinGame(){
        if(gridData[0] !== "def" && (gridData[0] === gridData[1] && gridData[0] === gridData[2])){
            winIdx = [0,1,2];
            this.setState({winType: gridData[0]});
        }else if(gridData[3] !== "def" && (gridData[3] === gridData[4] && gridData[3] === gridData[5])){
            winIdx = [3,4,5];
            this.setState({winType: gridData[3]});
        }else if(gridData[6] !== "def" && (gridData[6] === gridData[7] && gridData[7] === gridData[8])){
            winIdx = [6,7,8];
            this.setState({winType: gridData[6]});
        }else if(gridData[0] !== "def" && (gridData[0] === gridData[3] && gridData[0] === gridData[6])){
            winIdx = [0,3,6];
            this.setState({winType: gridData[0]});
        }else if(gridData[1] !== "def" && (gridData[1] === gridData[4] && gridData[1] === gridData[7])){
            winIdx = [1,4,7];
            this.setState({winType: gridData[1]});
        }else if(gridData[2] !== "def" && (gridData[2] === gridData[5] && gridData[2] === gridData[8])){
            winIdx = [2,5,8];
            this.setState({winType: gridData[2]});
        }else if(gridData[6] !== "def" && (gridData[6] === gridData[4] && gridData[6] === gridData[2])){
            winIdx = [6,4,2];
            this.setState({winType: gridData[6]});
        }else if(gridData[0] !== "def" && (gridData[0] === gridData[4] && gridData[0] === gridData[8])){
            winIdx = [0,4,8];
            this.setState({winType: gridData[0]});
        }
    }

    render(){
        return (
            <View style={styles.container}>
                <Text style={styles.heading}>Play TicTacToe Game</Text>
                <View style={styles.tttcontainer}>
                    {
                        gridData.map((gridtype, i) => {
                            const isWinCell = winIdx.indexOf(i) > -1 ? styles.winCell : {};
                            return (
                            <TouchableOpacity key={i} onPress={()=>{this.setItem(i)}} style={[styles.cellcontainer, isWinCell]}>
                                <View>
                                    {this.choseItemIcon(gridtype)}
                                </View>
                            </TouchableOpacity>
                            )
                        })
                    }
                </View>
                <View style={styles.reset}>
                    <Button title="Reset" onPress={this.resetGame}  color="red"/>
                </View>
                {
                    this.state.winType === "circle" && <Text>Circle wins the game</Text>
                }
                {
                    this.state.winType === "cross" && <Text>Cross wins the game</Text>
                }
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
       width: "100%",
       justifyContent: "center",
       alignItems: "center",
       paddingTop: 20,
       height: "100%",
       backgroundColor: "#31c2fe"
    },
    heading:{
        color: "red",
        fontWeight: "bold",
        fontSize: 22,
        width: "80%",
        paddingBottom: 20
    },
    tttcontainer: {
        backgroundColor: "#ffc931",
        height: 150,
        flexWrap: "wrap",
        width: "90%"
    },
    cellcontainer: {
        width: "33.33%",
        height: 50,
        borderWidth:1,
        borderColor: "black",
        justifyContent: "center",
        alignItems: "center"
    },
    winCell:{
        backgroundColor: "green"
    },
    icon: {
        width: 25,
        height: 25
    },
    reset: {
        marginTop: 20
    }
});