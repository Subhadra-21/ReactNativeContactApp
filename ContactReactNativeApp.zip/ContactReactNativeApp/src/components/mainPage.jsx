import React, {Component} from 'react';

import {Button, Container, Header, Text, Left, Body, Right, Title, Icon, Drawer, Content} from 'native-base';

import {SafeAreaView, View, StyleSheet, ScrollView} from 'react-native';

import NavBar from './navbar.jsx';
import TicTacToe from './ticTacToe.jsx';
import AudioPlay from './audio.jsx';
import LuckyDraw from './luckydraw.jsx';

class MainPageOld extends Component{
    constructor(props){
        super(props);
        this.state = {isLoading: true};
       // this.drawer = React.createRef();

        this.closeDrawer = this.closeDrawer.bind(this);
        this.openDrawer = this.openDrawer.bind(this);
    }
    async UNSAFE_componentWillMount(){
       await Expo.Font.loadAsync({
            'Roboto': require('native-base/Fonts/Roboto.ttf'),
            'Roboto_medium': require('native-base/Fonts/Roboto_medium.ttf')
        });
        this.setState({isLoading: false});
    }
    openDrawer(){
        this.drawer._root.open();
    }
    closeDrawer(){
        this.drawer._root.close();
    }
    render(){
        if(this.state.isLoading){ 
            return <View style={styles.container}><Text>Loading...</Text></View>
        }    
        return (
                <Drawer ref={(ref) => { this.drawer = ref; }} content={<NavBar />} onClose={this.closeDrawer}>
                    <Container>
                        <Header>
                        <Left>
                            <Button transparent onPress={this.openDrawer}>
                                <Icon name='menu' />
                            </Button>
                        </Left>
                        <Body>
                            <Title>Sample Pages</Title>
                        </Body>
                        </Header>
                    </Container>
                </Drawer>
          
        );
    }
}

const keyMap = {
    ticTacToe: TicTacToe,
    audio: AudioPlay,
    luckyDraw: LuckyDraw
};

export default class MainPage extends Component{
    constructor(props){
        super(props);
        this.state = {isLoading: true,  selTab: '1'};
    }
    async UNSAFE_componentWillMount(){
       await Expo.Font.loadAsync({
            'Roboto': require('native-base/Fonts/Roboto.ttf'),
            'Roboto_medium': require('native-base/Fonts/Roboto_medium.ttf')
        });
        this.setState({isLoading: false});
    }
    render(){
        const Comp = keyMap[this.state.selTab];
        if(this.state.isLoading){ 
            return <View style={styles.container}><Text>Loading...</Text></View>
        }    
        return (
            <SafeAreaView style={styles.main}>
                <ScrollView>
                <Container>
                    <Header>
                    <Left>
                        <Button transparent onPress={this.openDrawer}>
                            <Icon name='menu' />
                        </Button>
                    </Left>
                    <Body>
                        <Title>Sample Pages</Title>
                    </Body>
                    </Header>
                    <View style={styles.pageContent}>
                        <View style={styles.navbar}><NavBar handleClick={(keyProp)=>this.setState({selTab: keyProp})}/></View>
                        <View style={styles.navContent}>
                        { Comp ? <Comp /> : <Text>Home Page :-)</Text>
                        }
                        </View>
                    </View>
                </Container>
                </ScrollView>
            </SafeAreaView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center"
    },
    main:{
        flex: 1
    },  
    pageContent: {
        flex: 1,
        flexDirection: "row"
    },
    navbar: {
        flex: 1,
        borderWidth: 1,
        borderColor: "black"
    },
    navContent: {
        flex: 3,
        borderWidth: 1,
        borderColor: "black"
    }
});