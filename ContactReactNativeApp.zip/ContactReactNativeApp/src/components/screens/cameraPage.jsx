import React, {Component} from 'react';

import {SafeAreaView, View, Image, Text, TouchableOpacity, StyleSheet} from 'react-native';

import { Camera } from 'expo-camera';
import {FontAwesome, Ionicons  } from '@expo/vector-icons';


export default class CameraComp extends Component{
    constructor(props){
        super(props);
        this.state = {
            hasCameraPermission: null,
            type: Camera.Constants.Type.back,
            flashMode: Camera.Constants.FlashMode.off
        }
    }

    async componentDidMount(){
        const {status} = await Camera.requestPermissionsAsync();
        this.setState({ hasCameraPermission: status === 'granted'});
    }

    toggleFlashMode = () => {
        this.setState(
            {
                flashMode: this.state.flashMode === Camera.Constants.FlashMode.off ? Camera.Constants.FlashMode.on:Camera.Constants.FlashMode.off
            }
        );
    }

    flipCameraType = () => {
        this.setState(
            {
                type: this.state.type === Camera.Constants.Type.back ? Camera.Constants.Type.front: Camera.Constants.Type.back
            }
        );
    }

     takePicture = async () => {
        if(this.cameraRef ){
            let photo = await this.cameraRef.takePictureAsync();
            this.props.navigation.navigate("MyProfile",{
                photo
            })
        }
    }
    
    render(){
        const hasPermission = this.state.hasCameraPermission;
        if (hasPermission === null) {
            return <View />;
          }
          if (hasPermission === false) {
            return <Text>No access to camera</Text>;
          }
        return (
                <View style={styles.pageView}>
                   <Camera 
                        ref={(ref)=> this.cameraRef =ref }
                        style={styles.cameraView}
                        type={this.state.type}
                        flashMode={this.state.flashMode}
                   >
                       <View style={styles.buttonContainer}>
                        <TouchableOpacity
                                style={styles.button}
                                onPress={this.flipCameraType}>
                               <FontAwesome name="refresh" size={30} color="black" />
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={styles.button}
                            onPress={this.takePicture}>
                            <FontAwesome name="camera" size={30} color="black" />
                        </TouchableOpacity>    
                        <TouchableOpacity
                            style={[styles.button, (this.state.flashMode === Camera.Constants.FlashMode.on ? styles.flashon : {})]}
                            onPress={this.toggleFlashMode}>
                             <FontAwesome name="flash" size={30} color="black" />
                        </TouchableOpacity>
                        </View>
                    </Camera>
                </View>
        );
    }
}

const styles = StyleSheet.create({
    pageView: {
        flex: 1
    },
    cameraView: {
        flex: 1
    },
    buttonContainer: {
        flex: 1,
        backgroundColor: 'transparent',
        flexDirection: 'row',
        margin: 20,
        justifyContent: "space-around",
        alignItems: "center"
      },
      button: {
          alignSelf: "flex-end",
          alignContent: "flex-end",
          padding: 10,
          backgroundColor: "white",
          borderRadius: 10
      },
      flashon: {
        backgroundColor: "grey",
      },
      text: {
        fontSize: 18,
        color: 'white',
      },
});