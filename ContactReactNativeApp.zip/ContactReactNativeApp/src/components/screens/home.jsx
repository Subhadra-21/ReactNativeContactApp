import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import {Button, Container} from 'native-base';

export default class Home extends React.Component {
    render(){
        return (
            <View style={styles.container}>
                    <Button  onPress={()=>{ this.props.navigation.navigate('TicTacToe'); }} warning style={styles.button}>
                        <Text>Play TicTacToe</Text>
                    </Button>
                    <Button  onPress={()=>{ this.props.navigation.navigate('Audio'); }} success style={styles.button}>
                        <Text>Play Numbers</Text>
                    </Button>
                    <Button  onPress={()=>{ this.props.navigation.navigate('NumberGame'); }} info style={styles.button}>
                        <Text>Lucky Game</Text>
                    </Button>
                    <Button  onPress={()=>{ this.props.navigation.navigate('MyProfile'); }} warning style={styles.button}>
                        <Text>My Profile</Text>
                    </Button>
                    <Button  onPress={()=>{ this.props.navigation.navigate('ContactPage'); }} warning style={styles.button}>
                        <Text>Manage Contact</Text>
                    </Button>
                    <Text>This is the home page :-) !!!</Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: "center",
    alignItems: "center"
  },
  button:{
      margin: 20,
      padding: 30,
      alignSelf: "center",
      textAlign: "center"
  }
});
