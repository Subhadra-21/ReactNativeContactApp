import React, {Component} from 'react';

import {SafeAreaView, View, Image, Text, TouchableOpacity, StyleSheet} from 'react-native';

export default class MyProfile extends Component{
    constructor(props){
        super(props);
        this.state = {
            profileImage: require('../../../assets/defProfile.png')
        }
    }
    static getDerivedStateFromProps(props, state){
        if(props.route && props.route.params && props.route.params.photo ){
            return {profileImage: props.route.params.photo };
        }
        return null;
    }
    render(){
        return (
                <View style={styles.pageView}>
                    <View style={styles.imgContainer}>
                        <View>
                            <Image 
                                source={this.state.profileImage}
                                style={styles.pimage}
                            />
                        </View>    
                        <TouchableOpacity style={styles.imgBtn} onPress={()=>{this.props.navigation.navigate("CameraPage")}}>
                            <Text>Update Image</Text>    
                        </TouchableOpacity>  
                        <TouchableOpacity style={styles.imgBtn} onPress={()=>{this.props.navigation.navigate("FriendList")}}>
                            <Text>Friend List</Text>    
                        </TouchableOpacity>    
                    </View>
                    
                    <View style={styles.infoContainer}>
                        <Text style={styles.text}>Name: Test Name</Text>
                        <Text style={styles.text}>Contact: 65827976983</Text>
                    </View>
                </View>
        );
    }
}

const styles = StyleSheet.create({
    pageView: {
        flex: 1
    },
    imgContainer:{
        flex: 2,
        justifyContent: "center",
        alignItems: "center"
    },
    infoContainer:{
        flex: 1,
       justifyContent: "flex-start",
        alignItems: "center",
        borderColor: "red",
        borderWidth: 1,
        backgroundColor: "yellow"
    },
    pimage: {
        height: 200,
        width: 200,
        borderRadius:40,
        borderWidth: 2,
        borderColor: "red"
    },
    imgBtn:{
        marginTop: 40,
        backgroundColor: "violet",
        padding:20,
        borderRadius: 10
    },
    text:{
        fontSize: 24,
        marginTop: 10
    }
});