import React from 'react';
import { StyleSheet, Text, View, ScrollView, Alert, TouchableWithoutFeedback, Keyboard } from 'react-native';
import {Form,  Label, Input, Item, Button} from 'native-base';
import ls from 'react-native-local-storage';

export default class EditContactPage extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      fname: "",
      lname: "",
      phone: "",
      email: "",
      address: "",
      key: "",
    }
  }

  componentDidMount = () => {
    const {navigation} = this.props;
    navigation.addListener("focus", ()=>{
      this.getContact(this.props.route.params.key);
    });
  }

  getContact = async (key) => {
    await ls.get(key)
    .then(contact => {
      const contactData = JSON.parse(contact);
      console.log(contactData);
      contactData.key = key;
      this.setState(contactData);
    })
    .catch(err => console.log(err))
  }

  handleInputChange = ( value, prop) => {
    this.setState({[prop]: value});
  }

  updateContact =  () => {
    const {
      fname,
      lname,
      phone,
      email,
      address,
    } = this.state;
    if(fname && lname && phone && email && address){
      const contactDetails = {fname, lname, phone, email, address};
      console.log(this.state)
      ls.merge(this.state.key, JSON.stringify(contactDetails))
      .then(() => {
        this.props.navigation.goBack();
      })
      .catch(err => console.log(err));
    }
  }

    render(){
        return (
          <TouchableWithoutFeedback onPress={Keyboard.dismiss} style={styles.pcontainer}>
          <ScrollView style={styles.container}>
              <Form>
                <Item floatingLabel style={styles.inputItem}>
                  <Label>First Name</Label>
                  <Input 
                    value={this.state.fname}
                    onChangeText={(text)=>{this.handleInputChange(text,"fname")}}
                  />
                </Item>
                <Item floatingLabel style={styles.inputItem}>
                <Label>Last Name</Label>
                  <Input 
                    value={this.state.lname}
                    onChangeText={(text)=>{this.handleInputChange(text,"lname")}}
                  />
                </Item>
                <Item floatingLabel style={styles.inputItem}>
                <Label>Phone Number</Label>
                  <Input 
                    value={this.state.phone}
                    keyboardType="decimal-pad"
                    onChangeText={(text)=>{this.handleInputChange(text,"phone")}}
                  />
                </Item>
                <Item floatingLabel style={styles.inputItem}>
                <Label>Email</Label>
                  <Input 
                    value={this.state.email}
                    onChangeText={(text)=>{this.handleInputChange(text,"email")}}
                  />
                </Item>
                <Item floatingLabel style={styles.inputItem}>
                <Label>Address</Label>
                  <Input 
                    value={this.state.address}
                    onChangeText={(text)=>{this.handleInputChange(text,"address")}}
                  />
                </Item>
              </Form>
              <Button full success style={styles.button} onPress={this.updateContact}>
                <Text style={styles.buttonText}>Update</Text>
              </Button>
              <View style={styles.empty}>

              </View>
          </ScrollView>
       </TouchableWithoutFeedback>  
        );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    margin: 10,
    height: 500
  },
  inputItem: {
    margin: 10
  },
  button: {
    backgroundColor: "violet",
    marginTop: 40
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold"
  },
  empty: {
    height: 500,
    backgroundColor: "#FFF"
  }
})
