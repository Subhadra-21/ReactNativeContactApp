import React from 'react';
import { StyleSheet, Text, View, ScrollView, Alert , Linking, Platform} from 'react-native';
import {Button, Card} from 'native-base';
import ls from 'react-native-local-storage';

export default class ViewContactsPage extends React.Component {
    constructor(props){
      super(props);
      this.state = {
        fname: "",
        lname: "",
        phone: "",
        email: "",
        address: "",
        key: ""
      }
    }

    componentDidMount = () => {
      const {navigation} = this.props;
      navigation.addListener("focus", ()=>{
        this.getContact(this.props.route.params.key);
      });
    }

    getContact = async (key) => {
      await ls.get(key)
      .then(contact => {
        const contactData = JSON.parse(contact);
        console.log(contactData);
        contactData.key = key;
        this.setState(contactData);
      })
      .catch(err => console.log(err))
    }

    editContact = () => {
      this.props.navigation.navigate("EditContactPage", {key: this.state.key});
    }

    deleteContact = () => {
      Alert.alert(`do you want to delete ${this.state.fname}?`, "", [
        {
          text: "Confirm",
          type: "default",
          onPress: async ()=>{
            await ls.remove(this.state.key)
            .then(()=>{
              this.props.navigation.goBack();
            })
            .catch(err => console.log(err))
          }
        },
        {
          text: "Cancel",
          type: "cancel"
        }
      ])
    }

    makeCall = () => {
      const phone = this.state.phone;
      let phoneNum = phone;
      if(Platform.OS !== 'android'){
        phoneNum = `telprompt:${phone}`;
      }else{
        phoneNum = `tel:${phone}`;
      }

      Linking.canOpenURL(phoneNum)
      .then((supported) => {
        if(!supported) return Alert.alert("can not open phone app");
        else Linking.openURL(phoneNum)
      })
      .catch(err => console.log(err));
    }

    makeSms = () => {
      const phone = this.state.phone;
      let phoneNum = `sms:${phone}`;
      Linking.canOpenURL(phoneNum)
      .then((supported) => {
        if(!supported) return Alert.alert("can not open phone app");
        else Linking.openURL(phoneNum)
      })
      .catch(err => console.log(err));
    }

    render(){
        if(!this.state.key) return null;
        return (
            <ScrollView style={styles.container}>
                <View style={styles.contactIconContainer}>
                  <Text style={styles.contactIcon}>{this.state.fname[0].toUpperCase()} {this.state.lname[0].toUpperCase()}</Text>
                  <View style={styles.nameContainer}>
                    <Text style={styles.name}>{this.state.fname} {this.state.lname}</Text>
                  </View>
                </View>
                
                <View>
                  <Text style={styles.infoText}>Phone: {this.state.phone}</Text>
                  <Text style={styles.infoText}>Email: {this.state.email}</Text>
                  <Text style={styles.infoText}>Address: {this.state.address}</Text>
                </View>
                <View style={styles.actionContainer}>
                    <Button onPress={this.editContact} style={styles.actionButton}>
                      <Text  style={styles.actionText}>Edit</Text>
                    </Button>
                    <Button onPress={this.deleteContact} style={styles.actionButton}>
                      <Text  style={styles.actionText}>Delete</Text>
                    </Button>
                </View>
                <View style={styles.actionContainer}>    
                    <Button onPress={this.makeCall} style={styles.actionButton}>
                      <Text  style={styles.actionText}>Call</Text>
                    </Button>
                    <Button onPress={this.makeSms} style={styles.actionButton}>
                      <Text  style={styles.actionText}>SMS</Text>
                    </Button>
                </View>
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff"
  },
  contactIconContainer: {
    height: 400,
    backgroundColor: "violet",
    alignItems: "center",
    justifyContent: "center"
  },
  contactIcon: {
    fontSize: 100,
    fontWeight: "bold",
    color: "#fff"
  },
  nameContainer: {
    width: "100%",
    height: 70,
    padding: 10,
    backgroundColor: "rgba(255,255,255,0.5)",
    justifyContent: "center",
    position: "absolute",
    bottom: 0
  },
  name: {
    fontSize: 24,
    color: "#000",
    fontWeight: "900"
  },
  infoText: {
    fontSize: 18,
    fontWeight: "300",
    padding: 10
  },
  actionContainer: {
    flexDirection: "row",
    marginTop: 20
  },
  actionButton: {
    flex: 1,
    justifyContent: "space-around",
    alignItems: "center",
    width: 100,
    margin: 10,
    backgroundColor: "violet"
  },
  actionText: {
    color: "#FFF",
    fontWeight: "900"
  }
});
