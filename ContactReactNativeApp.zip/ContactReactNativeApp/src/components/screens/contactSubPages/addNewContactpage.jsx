import React from 'react';
import { StyleSheet, Text, View, ScrollView, Alert, TouchableWithoutFeedback, Keyboard } from 'react-native';
import {Form,  Label, Input, Item, Button} from 'native-base';

import ls from 'react-native-local-storage';

/*
import MMKVStorage from "react-native-mmkv-storage";
const MMKVS = new MMKVStorage.Loader().initialize(); //initialise the db
*/

export default class AddNewContactPage extends React.Component {
    constructor(props){
      super(props);
      this.state = {
        fname: "",
        lname: "",
        phone: "",
        email: "",
        address: ""
      }
    }
    handleInputChange = ( value, prop) => {
      this.setState({[prop]: value});
    }
/*
    addContact = async () => {
      const {
        fname,
        lname,
        phone,
        email,
        address,
      } = this.state;
      if(fname && lname && phone && email && address){
        const contactDetails = {fname, lname, phone, email, address};
        console.log(contactDetails);
        await MMKVS.setMapAsync(Date.now().toString(), contactDetails)
        .then( async ()=>{
          let allInstances = await MMKVS.getAllInstanceIDs();
          console.log(allInstances);
          // this.props.navigation.navigate("ContactPage");
        })
        .catch(err => console.log(err));
      }else{
        Alert.alert("All fields required.");
      }
    }
*/

    addContact = () => {
      const {
        fname,
        lname,
        phone,
        email,
        address,
      } = this.state;
      if(fname && lname && phone && email && address){
        const contactDetails = {fname, lname, phone, email, address};
        ls.save(Date.now().toString(), JSON.stringify(contactDetails))
        .then(() => {
          this.props.navigation.navigate("ContactPage");
        })
        .catch(err => console.log(err));
      }
    }

    render(){
        return (
          <TouchableWithoutFeedback onPress={Keyboard.dismiss} style={styles.pcontainer}>
            <ScrollView style={styles.container}>
                <Form>
                  <Item floatingLabel style={styles.inputItem}>
                    <Label>First Name</Label>
                    <Input 
                      value={this.state.fname}
                      onChangeText={(text)=>{this.handleInputChange(text,"fname")}}
                    />
                  </Item>
                  <Item floatingLabel style={styles.inputItem}>
                  <Label>Last Name</Label>
                    <Input 
                      value={this.state.lname}
                      onChangeText={(text)=>{this.handleInputChange(text,"lname")}}
                    />
                  </Item>
                  <Item floatingLabel style={styles.inputItem}>
                  <Label>Phone Number</Label>
                    <Input 
                      value={this.state.phone}
                      keyboardType="decimal-pad"
                      onChangeText={(text)=>{this.handleInputChange(text,"phone")}}
                    />
                  </Item>
                  <Item floatingLabel style={styles.inputItem}>
                  <Label>Email</Label>
                    <Input 
                      value={this.state.email}
                      onChangeText={(text)=>{this.handleInputChange(text,"email")}}
                    />
                  </Item>
                  <Item floatingLabel style={styles.inputItem}>
                  <Label>Address</Label>
                    <Input 
                      value={this.state.address}
                      onChangeText={(text)=>{this.handleInputChange(text,"address")}}
                    />
                  </Item>
                </Form>
                <Button full success style={styles.button} onPress={this.addContact}>
                  <Text style={styles.buttonText}>Save</Text>
                </Button>
                <View style={styles.empty}>

                </View>
            </ScrollView>
         </TouchableWithoutFeedback>  
        );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    margin: 10,
    height: 500
  },
  inputItem: {
    margin: 10
  },
  button: {
    backgroundColor: "violet",
    marginTop: 40
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold"
  },
  empty: {
    height: 500,
    backgroundColor: "#FFF"
  }
});
