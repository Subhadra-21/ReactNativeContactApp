import React, {Component} from 'react';
import {View, StyleSheet, SafeAreaView, Text} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createDrawerNavigator} from '@react-navigation/drawer';

import HomeScreen from './home.jsx';
import TicTacToe from '../ticTacToe.jsx';
import Audio from '../audio.jsx';
import LuckyDraw from '../luckydraw.jsx';
import MyProfile from './myProfilePage.jsx';
import CameraPage from './cameraPage.jsx';
import FriendListPage from './friendList.jsx';
import ContactPage from './contactManagePage.jsx';
import AddNewContactPage from './contactSubPages/addNewContactpage.jsx';
import EditContactPage from './contactSubPages/editContactPage.jsx';
import ViewContactPage from './contactSubPages/viewContactsPage.jsx';

/*========================== stack container===============================*/
const Stack = createStackNavigator();
class MainPageStackContainer extends Component{
    render(){
        const headerOptions = {
            headerStyle:{backgroundColor:"violet"},
            headerTintColor: 'black', //text color
            headerTitleStyle: {
                fontWeight: 'bold'
            }
        };
        return(
            <NavigationContainer>
                <Stack.Navigator initialRouteName="Home" screenOptions={headerOptions}>
                    <Stack.Screen name="Home" component={HomeScreen} options={{title:"Home Page"}}/>
                    <Stack.Screen name="TicTacToe" component={TicTacToe} options={{title:"TicTacToe"}}/>
                    <Stack.Screen name="Audio" component={Audio} options={{title:"Play Numbers"}}/>
                    <Stack.Screen name="NumberGame" component={LuckyDraw} options={{title:"Lucky Draw"}}/>
                    <Stack.Screen name="MyProfile" component={MyProfile} options={{title: "Profile View"}} />
                    <Stack.Screen name="CameraPage" component={CameraPage} options={{title:"Update Photo"}}/>
                    <Stack.Screen name="FriendList" component={FriendListPage} options={{title:"My Friends"}}/>
                    <Stack.Screen name="ContactPage" component={ContactPage} options={{title:"Manage Contacts"}}/>
                    <Stack.Screen name="AddNewContactPage" component={AddNewContactPage} options={{title:"Add Contacts"}}/>
                    <Stack.Screen name="EditContactPage" component={EditContactPage} options={{title:"Edit Contacts"}}/>
                    <Stack.Screen name="ViewContactPage" component={ViewContactPage} options={{title:"View Contacts"}}/>
                </Stack.Navigator>
            </NavigationContainer>    
        );
    }
}
/*========================== stack container Ends===============================*/

/*======================== Tab container=============================*/
const Tab = createBottomTabNavigator();
class MainPageTabContainer extends Component{
    render(){
        return(
            <NavigationContainer>
                <Tab.Navigator initialRouteName="Home">
                    <Tab.Screen name="Home" component={HomeScreen} options={{title:"Home"}}/>
                    <Tab.Screen name="TicTacToe" component={TicTacToe} options={{title:"TicTacToe"}}/>
                    <Tab.Screen name="Audio" component={Audio} options={{title:"Numbers"}}/>
                    <Tab.Screen name="NumberGame" component={LuckyDraw} options={{title:"Lucky"}}/>
                </Tab.Navigator>
            </NavigationContainer>    
        );
    }
}
/*===========Tab container==================*/


/*============drawer conatiner==================*/
const Drawer = createDrawerNavigator();
class MainPageDrawerContainer extends Component{
    render(){
        return(
            <NavigationContainer>
                <Drawer.Navigator initialRouteName="Home">
                    <Drawer.Screen name="Home" component={HomeScreen} options={{title:"Home"}}/>
                    <Drawer.Screen name="TicTacToe" component={TicTacToe} options={{title:"TicTacToe"}}/>
                    <Drawer.Screen name="Audio" component={Audio} options={{title:"NumbersSound"}}/>
                    <Drawer.Screen name="NumberGame" component={LuckyDraw} options={{title:"LuckyDraw"}}/>
                </Drawer.Navigator>
            </NavigationContainer>    
        );
    }
}

export default MainPageStackContainer;