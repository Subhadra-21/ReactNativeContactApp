import React, {Component} from 'react';

import {SafeAreaView, View, Image, Text, TouchableOpacity, StyleSheet} from 'react-native';

import * as Contacts from 'expo-contacts';
import { ScrollView } from 'react-native-gesture-handler';

export default class MyProfile extends Component{

    constructor(props){
        super(props);
        this.state = {
            hasPermission: null,
            friendList : [],
        }
    }

    async componentDidMount(){
        const {status} = await Contacts.requestPermissionsAsync();
        let stateObj = {
            hasPermission: status === 'granted'
        }
        if(status === 'granted'){
            const { data } = await Contacts.getContactsAsync();
            console.log(data);
            stateObj.friendList = data.map(a => ({firstName: a.firstName, name: a.name}) );
        }
        this.setState(stateObj);
    }
    render(){
        const {friendList, hasPermission} = this.state;
        if (hasPermission === null) {
            return <View />;
        }
        if (hasPermission === false) {
        return <Text>No access to Contacts</Text>;
        }
        return (
                <ScrollView style={styles.pageView}>
                    {
                        friendList.length === 0 ? <Text>No contacts found</Text> : 
                        <View style={styles.contactContainer}>
                            {
                                friendList.map((frnd, i) => {
                                    return (
                                        <TouchableOpacity style={styles.person} key={i}>
                                            <View style={styles.imageContainer}>
                                            {frnd.image ? 
                                                <Image source={frnd.image} style={styles.contactPic} /> 
                                            : <Image source={require('../../../assets/defProfile.png')} style={styles.contactPic} /> }
                                            </View>
                                            <Text style={styles.textStyle}>{frnd.name}</Text>
                                        </TouchableOpacity>
                                    )
                                })
                            }
                        </View>
                    }
                   
                </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
    pageView: {
        flex: 1
    },
    contactContainer: {
        flex: 1,
        padding: 20
    },
    person: {
        padding: 5,
        borderBottomWidth: 1,
        borderBottomColor: "grey",
        flexDirection: "row"
    },
    imageContainer: {
        backgroundColor: "green",
        borderRadius: 50,
        width: 40,
        height: 40,
        justifyContent: "center",
        alignItems: "center",
        marginRight: 10
    },  
    contactPic: {
        width: 25,
        height: 25, 
    },
    textStyle: {
        alignSelf: "center"
    }
});