import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity, FlatList } from 'react-native';
import {Card, CardItem} from 'native-base';
import { AntDesign } from '@expo/vector-icons'; 
import ls from 'react-native-local-storage';

export default class ContactManagePage extends React.Component {
    constructor(props){
      super(props);
      this.state = {
        contactsList : [],
      };
    }

    componentDidMount = () => {
      const {navigation} = this.props;
      navigation.addListener("focus", ()=>{
        this.getContacts();
      });
      return null;
    }

    getContacts = async () => {
      const keys = await ls.getAllKeys();
      console.log("keys",keys);
      const contacts = [];
      ls.getSet(keys, (key, value)=>{
        contacts.push({...JSON.parse(value), key})
      })
      .then(() => {
        console.log(contacts);
        this.setState({contactsList : contacts});
      })
      .catch(err => console.log(err));
    }

    render(){
        return (
            <View style={styles.container}>
                <FlatList 
                  data={this.state.contactsList}
                  keyExtractor={(item) => item.key}
                  renderItem={(obj) => {
                    // console.log(obj); //{item, index, separators}
                    const item  = obj.item;
                    return (
                      <TouchableOpacity onPress={()=>{
                        this.props.navigation.navigate("ViewContactPage", {key:item.key})
                      }}>
                        <Card style={styles.listItem}>
                          <CardItem style={styles.iconContainer}>
                            <Text style={styles.contactIcon}>{item.fname[0].toUpperCase()}</Text>
                          </CardItem>
                          <CardItem style={styles.infoContainer}>
                            <Text style={styles.infoText}>{item.fname} {item.lname}</Text>
                            <Text style={styles.infoText}>{item.phone}</Text>
                          </CardItem>
                        </Card>
                      </TouchableOpacity>
                    )
                  }}
                />
                <TouchableOpacity 
                  style={styles.floatButton} 
                  onPress={()=>{this.props.navigation.navigate('AddNewContactPage')}}>
                   <AntDesign name="plus" size={30} color="white" />
                </TouchableOpacity>
            </View>
        );
    }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff"
  },
  listItem: {
    flexDirection: "row",
    padding: 20
  },
  iconContainer: {
    width: 50,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "violet",
    borderRadius: 100
  },
  contactIcon: {
    fontSize: 28,
    color: "#fff"
  },
  infoContainer: {
    flexDirection: "column"
  },
  infoText: {
    fontSize: 16,
    fontWeight: "400",
    paddingLeft: 10,
    paddingTop: 2
  },
  floatButton: {
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.2)",
    alignItems: "center",
    justifyContent: "center",
    width: 60,
    position: "absolute",
    bottom: 10,
    right: 10,
    height: 60,
    backgroundColor: "violet",
    borderRadius: 100
  }
});