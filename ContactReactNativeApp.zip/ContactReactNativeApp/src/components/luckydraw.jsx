
import React, {Component} from 'react';

import {View, Text, TouchableOpacity, Image, StyleSheet, Button} from 'react-native';

var gridData = [{label:1},{label:2},{label:3},{label:4},{label:5},{label:6},{label:7},{label:8},{label:9},{label:10},{label:11},{label:12},{label:13},{label:14},{label:15},{label:16},{label:17},{label:18},{label:19},{label:20},{label:21},{label:22},{label:23},{label:24},{label:25}];

export default class LuckyDraw extends Component{
    constructor(props){
        super(props);
        this.state = {
            luckyNum: Math.floor(Math.random()*25)+1,
            tries: 3,
            isWin: false
        }
        this.resetGame = this.resetGame.bind(this);
    }
    getItem(item){
       switch(item.type){
           case "win" : 
           return <Image source={require('../../assets/emoji/wonsmiley.jpg')} style={styles.icon} />;
           break;
           case "loss": 
           return <Image source={require('../../assets/emoji/loss.jpg')} style={styles.icon}/>;
           break;
           default: 
           return <Text>{item.label}</Text>;
       }
    }
    checkWin(idx){
        var grid = gridData[idx];
        if(grid.type || this.state.isWin || this.state.tries<1) return;

        if(grid.label === this.state.luckyNum){
            grid.type = 'win';
            this.setState({
                tries: this.state.tries - 1,
                isWin: true
            });
        }else{
            grid.type = 'loss'; 
            this.setState({
                tries: this.state.tries - 1
            });
        } 
        
    }
    resetGame(){
        gridData = [{label:1},{label:2},{label:3},{label:4},{label:5},{label:6},{label:7},{label:8},{label:9},{label:10},{label:11},{label:12},{label:13},{label:14},{label:15},{label:16},{label:17},{label:18},{label:19},{label:20},{label:21},{label:22},{label:23},{label:24},{label:25}];
        this.setState( {
            luckyNum: Math.floor(Math.random()*25)+1,
            tries: 3,
            isWin: false
        });
    }
    render(){
        return (
            <View style={styles.container}>
                <Text style={styles.heading}>Pick a lucky number and win the game. 3 tries allowed</Text>
                {this.state.tries === 0 && !this.state.isWin ? <Text>No more tries, Better luck next time</Text> : null}
                {
                    this.state.isWin ? 
                    <View style={{justifyContent:"center", alignItems: "center"}}>
                        <Image source={require('../../assets/emoji/win.jpg')} style={styles.iconWin}/>
                        <Text style={{justifyContent:"center", alignItems: "center", textAlign:"center"}}>Wooow, You won the game... Congratulation!!</Text>
                    </View> : null
                }
                <View style={styles.tttcontainer}>
                    {
                        gridData.map((grid, i) => {
                            return (
                            <TouchableOpacity key={i} onPress={()=>{this.checkWin(i)}} style={[styles.cellcontainer]}>
                                <View>
                                   {this.getItem(grid)}
                                </View>
                            </TouchableOpacity>
                            )
                        })
                    }
                </View>
                <Button title="Reset Game" onPress={this.resetGame} color="red" style={styles.resetBtn}/>
                {/* <Text>{this.state.luckyNum}</Text> */}
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
       width: "100%",
       justifyContent: "center",
       alignItems: "center",
       paddingTop: 20,
       height: "100%",
       backgroundColor: "#31c2fe"
    },
    heading:{
        color: "red",
        fontWeight: "bold",
        fontSize: 22,
        width: "80%",
        paddingBottom: 20
    },
    tttcontainer: {
        backgroundColor: "white",
        height: 250,
        flexDirection: "row",
        flexWrap: "wrap",
        width: "90%",
        marginBottom: 30
    },
    cellcontainer: {
        width: "20%",
        height: 50,
        borderWidth:1,
        borderColor: "black",
        justifyContent: "center",
        alignItems: "center"
    },
    icon:{
        width: 30,
        height:30
    },
    resetBtn:{
    },
    iconWin:{
        width: 100,
        height: 100
    }
});