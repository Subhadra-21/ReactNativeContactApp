import 'react-native-gesture-handler';
import React from 'react';
import { StyleSheet, Text, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';

import MainPage from './src/components/mainPage.jsx';
import ReactNavPage from './src/components/screens/mainPageNav.jsx';

function App1() {
  return (
    <ScrollView style={styles.container}>
      <MainPage />
    </ScrollView>
  );
}

export default function App() {
  return (
    <ReactNavPage />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff'
  },
});
